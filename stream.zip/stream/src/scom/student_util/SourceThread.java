package scom.student_util;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class SourceThread extends Thread {
	
static Map<Integer,String> mp = new HashMap<>();
	// lets use ConcurrentHashMap<>();
	
	//static Map<Integer,String> mp = new ConcurrentHashMap<>();
	
	

	@Override
	public void run() {
		// TODO Auto-generated method stub
		try {
			Thread.sleep(200);
			
			mp.put(108,"abc");
			System.out.println(mp);
		}catch (Exception e) {
			// TODO: handle exception
			System.out.println("child thread going to add elements");
			e.printStackTrace();
		}
		
	}



	public static void main(String[] args) throws InterruptedException  {
		// TODO Auto-generated method stub
		
		mp.put(101,"zxc");
		mp.put(102,"mnb");
		mp.put(104,"lkj");

		SourceThread source = new SourceThread();
		source.start();
		
		// the reason here for throwing Concurrent modification exception is that 
		   // one is main thread which is doing the task of iterating the map
		   // another thread on same time tring to update the map that;s why throwing Concurrent modification exception
		
		for(Object O : mp.entrySet())
		{
			Object s = O;
			System.out.println(s);
			Thread.sleep(1000);
			
		}
		System.out.println("========"+mp);
	}

}
