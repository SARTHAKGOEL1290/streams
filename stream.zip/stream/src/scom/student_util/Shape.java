package scom.student_util;

public class Shape {
	
	  int value = 5;
	     public void area( int a, int b ) throws NullPointerException
	   {
		               int sum = a+b;
	            System.out.println("this is inside Shape "+ sum);
	   }
	     public void perimeter(int a, int b)
	     {
	    	 System.out.println("Peremiter indise SHAPE CLass");
	     }
  
}
