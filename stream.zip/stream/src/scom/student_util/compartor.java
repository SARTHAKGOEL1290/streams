package scom.student_util;

import java.util.Comparator;

public class compartor implements Comparator<Student>{

	@Override
	public int compare(Student o1, Student o2) {
		// TODO Auto-generated method stub
		return o1.getFees() - o2.getFees();
	}

}
