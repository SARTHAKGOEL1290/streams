package scom.student_util;

import java.util.Arrays;

public class Sample1 {

	// array   =  [0, 1, 0, 1, 0, 0, 1, 1, 1, 0]
	
	public static void doSort(int arr[])
	{
	    int Zerocount = 0, Onecount=0;
	    for(int i=0;i<arr.length;i++)
	    {
	    	if(arr[i]==0)
	    		Zerocount = Zerocount+1;
	    	else
	    		Onecount = Onecount+1;
	    }
	    
	    for(int i =0;i<Zerocount;i++)
	    	arr[i]=0;
	    
	    for(int i =Zerocount;i<arr.length;i++)
	    {
	    	arr[i]=1;
	    }
		//Arrays.sort(arr);
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] arr = {0, 1, 0, 1, 0, 0, 1, 1, 1, 0};
		
		
		for(int i =0;i<arr.length;i++)
		{
			System.out.print( arr[i]);
		}
		doSort(arr);
		System.out.println();
		for(int i =0;i<arr.length;i++)
		{
			System.out.print(arr[i]);
		}

	}

}
