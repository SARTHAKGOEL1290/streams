package scom.student_util;

public class demo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		   Shape s1 = new circle();
		
		   try {
			  
	        s1.area(10,20); 
	         System.out.println(s1.value);
	         s1.perimeter(10, 0);
		   }
		   catch(Exception e)
		   {
			   e.printStackTrace();
		   }
		  
	}
}