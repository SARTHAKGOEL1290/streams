package scom.student_util;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Stack;

public class ListSum {
  
	public static int findpairs(int[] arr,int target)
	{
	Map<Integer,Integer> map = new HashMap<>();
	int count =0;
	for(int i=0;i<arr.length;i++)
	{
		
		if(map.containsKey(target-arr[i]))
		{
			System.out.println(arr[i]+" ");
			count= count +1;
		}
		
		map.put(arr[i],i);
	}
	
	return count;
	}
		
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*
		 * Input:  arr[] = {1, 1, 1, 1}, sum = 2
                Output:  6
xplanation: There are 3! pairs with sum 2.


Input:  arr[] = {1, 5, 7, -1, 5}, sum = 6
Output:  3
Explanation: Pairs with sum 6 are (1, 5), (7, -1) & (1, 5)
(12,-1),

{10, 12, 10, 15, -1, 7, 6, 5, 4, 2, 1, 1, 1}, sum = 11
		 */
		int[] arr = {10, 12,10, 15, -1, 7, 6, 5, 4, 2, 1, 1, 1};
		int result = findpairs(arr,11);
		
		System.out.println(result);
		

	}

}
