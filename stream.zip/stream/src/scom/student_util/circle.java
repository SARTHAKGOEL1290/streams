package scom.student_util;

public class circle extends Shape {

	
	int value =9;  // value is NOT overridden hence if we cal this with the reference variable of Shape class it return shape class varible
	  public void area(int a, int b) throws ArithmeticException
	  {  
		  super.area(10,20);
	       System.out.println("Inside circle"+a*b);
	   }
	  




}
