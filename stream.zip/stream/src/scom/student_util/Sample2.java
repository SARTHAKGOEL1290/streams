package scom.student_util;

import java.util.Stack;

public class Sample2 {

	//String s  = {}(); {{[([])]}}
	// {[(]}
	// ((()()()())))

	
	public static boolean isValid(String s)
	{
		Stack<Character> s1= new Stack<>();
		
		char[] ch1 = s.toCharArray();
		int inc =0;
		int dec =0;
		for(int i=0;i<ch1.length;i++)
		{
			if(ch1[i]=='(' || ch1[i]=='[' || ch1[i]=='{' )
			{
				s1.push((ch1[i]));
				inc = inc+1;
			}
			
			else if(ch1[i]==')'  )
			{
				if(s1.isEmpty() == false && s1.peek() == '(' ) 
				{
					s1.pop();
					
				}
				dec=dec+1;
			}
			else if( ch1[i]=='}' )
			{
				
				if(s1.isEmpty() == false && s1.peek() == '{' ) 
				{
					s1.pop();
					
				}
				dec = dec+1;
			}
			else if( ch1[i]==']' )
			{
				
				if(s1.isEmpty() == false && s1.peek() == '[' ) 
				{
					s1.pop();
					
				}
			  dec = dec+1;
			}
			
			
		}
		
		//System.out.println(dec);
		
		if(s1.size()==0 && inc == dec)
			return true;
		else
		return false;
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//String str = "{{[([])]}}[[[";
		//test case2
		String str = "({({({})})}){}[";
		
		boolean res = isValid(str);
		System.out.println(res);

	}

}
