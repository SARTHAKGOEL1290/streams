package scom.student_util;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Spliterator;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Collection_sort {

	static List<Student> std = new ArrayList<>();
	
	public static List<Student> getComplist()
	{
		
		
		Student s1 = new Student(91,"rim",15,5000,"09");
		Student s2 = new Student(92,"sim",16,7000,"10");
		Student s3 = new Student(93,"tim",17,8000,"11");
		Student s4 = new Student(91,"lim",18,9000,"12");
		
		std.add(s3);
		std.add(s2);
		std.add(s1);
		
		
		std.add(s4);
		
		return std;
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
              
		getComplist();
		
	List<Integer> ll = Arrays.asList(9,8,10,7);
	Integer [] nums = {2,3,4,5};
	
	Arrays.sort(nums,Comparator.reverseOrder());
	
	 List<Integer> arr = Arrays.asList(nums);
	 System.out.println(arr.size());
	 
	
	
	Collections.sort(ll,(a,b)->a.compareTo(b));
	System.out.println("sorted list ->>>>>>>>>"+ll);
	
	// or
	Collections.sort(ll,Comparator.reverseOrder());
	System.out.println("sorted list in reverse order ->>>>>>>>>"+ll);
	
	
		
		System.out.println("collection before sorting is " + std);
	    // sort the list for non primitive data type we need Comparator class here
		// generic of doing this using another comparator class
		 Collections.sort(std,new compartor());
		System.out.println("collection after sorting is " + std);
		
		
//----------->>> now using comparator inside this class only 
	/*	
		Collections.sort(std,new Comparator<Student>() {

			@Override
			public int compare(Student o1, Student o2) {
				// TODO Auto-generated method stub
				return o1.name.compareTo(o2.name);
			}
		});
		System.out.println("collection after sorting according to name ---> " + std);
	}
	*/
		
   ////----------->>> now using comparator inside this class only with Lambda function
	
	Collections.sort(std,(o1,o2) -> o1.name.compareTo(o2.name));
  
	//System.out.println("collection after sorting according to name lambda---> " + std);
	
	Iterator itr = std.listIterator();
	while(itr.hasNext())
	{
	     System.out.println(itr.next());
	}
	
	// by using streams
	std.stream().sorted(Comparator.comparing(Student::getAge).reversed()).forEach(System.out::println);
	
	System.out.println("--------0999-9o-");
	//std.stream().sorted().forEach(e->System.out.println(e)); bcoz non premitive does notont he basis of only sorted.
	
	
	// stream to demonstrate sorting on the basis of filter and map 
	List<Integer> stt = std.stream().filter(e->e.getAge()>14).map(Student::getFees).sorted().collect(Collectors.toList());
	
	System.out.println("++++++++++++++"+stt);
	
	// stream to demonstrate map & reduce
	int l = std.stream().map(Student::getAge).reduce(0,(a,b)-> a+b).intValue();
	System.out.println(l);
	
	// std.stream().reduce(Integer::max).get();
	
	  double age_average = std.parallelStream().map(Student::getAge).mapToDouble(i->i).average().getAsDouble();
	  System.out.println("++++++++))))))))))))++++++"+age_average);
	  
	  
	
	// sort for 2d matrix according to column value
	  
	  int matrix[][] = { { 39, 27, 11, 42 },
              { 10, 93, 91, 90 },
              { 54, 78, 56, 89 },
              { 24, 64, 20, 20 } };
	  
	/*  Arrays.sort(matrix,new Comparator<int []>() {

		@Override
		public int compare(int[] o1, int[] o2) {
			// TODO Auto-generated method stub
			return o1[1]-o2[1];
		}
		  
	  }
	);
	*/
	  // using lambda function sorting in increasing order
	  Arrays.sort(matrix,(o1,o2)-> o1[3]-(o2[3]));
	  
	  for (int i = 0; i < matrix.length; i++) {
          for (int j = 0; j < matrix[i].length; j++)
              System.out.print(matrix[i][j] + " ");
          System.out.println();
      }
	  
	  
	  // get the data from list and store to map
	  LinkedHashMap<Integer,Integer> map = std.stream().filter(e-> e.getAge() > 15)
			  .collect(Collectors.toMap(Student::getSid, Student::getAge,(x, y) -> x,LinkedHashMap::new));
	  
	  System.out.println(map);
	
}
	
	
	
}
