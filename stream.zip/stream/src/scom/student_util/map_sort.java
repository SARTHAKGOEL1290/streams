package scom.student_util;

import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

public class map_sort {

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Map<String,Integer> map = new HashMap<>();
	  
		
		map.put("abc",11);
		map.put("abd",12);
		map.put("abe",13);
		map.put("abl",14);
		
		map.entrySet().stream().sorted(Map.Entry.comparingByKey(Comparator.reverseOrder())).forEach(System.out::println);
		
		System.out.println("----------------------------------");
		
		map.entrySet().stream().sorted(Map.Entry.comparingByValue()).forEach(System.out::println);
		
		
		// for non primitive data type
		Map<Student,Integer> stud = new TreeMap<>(new Comparator<Student>() {

			@Override
			public int compare(Student o1, Student o2) {
				// TODO Auto-generated method stub
				return o1.getFees()-o2.getFees();
			}
		});
		
		stud.put(new Student(91,"rim",19,9000,"09"), 201);
		stud.put(new Student(92,"lim",11,5000,"09"), 201);
		stud.put(new Student(93,"kim",13,6000,"09"), 201);
		stud.put(new Student(94,"aim",16,3000,"09"), 201);
		
		/*
		 *this peice is code is used to deonstrate that if the type is non primitive then we need 
		 *to override equals and hashcode methods like we did in Student class. 
		 *
		Student ll = new Student(94,"aim",16,3000,"09");
		Student rr = new Student(94,"aim",16,3000,"09");
		
		stud.put(ll,901);
		stud.put(rr, 801);
		
		*/
		
		
		System.out.println("--------00-0-000000000"+ stud);
		
		// for using Collection.sort first we nned to convert Map into list that will do later
		
		// sort using stream
		
		System.out.println("--------------- stream sorted in revetrse order");
		
		stud.entrySet().stream()
		.sorted(Map.Entry.comparingByKey(Comparator.comparing(Student::getAge).reversed())).
		forEach(System.out::println);
	         
	}

}
