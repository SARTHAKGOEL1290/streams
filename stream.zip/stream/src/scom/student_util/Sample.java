package scom.student_util;

public class Sample {

	// arrays of 0's 1's and 2's
	
	//arr = [0,1,2,2,1,0,0,1,2];
	//output = [0,0,0,1,1,1,2,2]
	
	static void findsort(int[] arr)
	{
		int zerocount =0, onecount =0,twocount =0;
		for(int i =0;i<arr.length;i++)
		{
			if(arr[i]==0)
				{
				zerocount = zerocount+1;
				}
			
			else if(arr[i]==1)
			{
				onecount = onecount+1;
			}
			
			else if(arr[i]==2)
			{
				twocount = twocount+1;
			}
		}
		int[] arr1 = new int[10];
		int i =0;
		while(i<zerocount-1)
		{
			arr1[i]=0;
			i++;
		}
		int j=i;
		while(j<i+onecount-1)
		{
			arr1[j]=1;
			j++;
		}
		int k = j;
		while(k<j+twocount-1)
		{
			arr1[k]=2;
			k++;
		}
		
		for(int ll =0;ll<arr.length;ll++)
	    	 System.out.print(arr1[ll]);
	
		
	}
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	     int arr[] = {0,1,2,2,1,0,0,1,2};
	     System.out.print("Array before sorting-----------");
	   //  for(int i =0;i<arr.length;i++)
	   // 	 System.out.print(arr[i]);
	     
	     findsort(arr);
	     
	     System.out.println();
	   //  System.out.print("Array after sorting-----------");
	    
	     
	    

	}

}
