package scom.student_util;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

public class util {
	
	public static Student getByname(String name)
	{
		Student s4 = new Student(11,"abc",19,5000,"10");
		Student s5 = new Student(12,"xyz",20,9000,"11");
		Student s6 = new Student(14,"ijk",22,7000,"12");
		
		List<Student> list = new ArrayList<>();
		list.add(s4);
		list.add(s5);
		list.add(s6);
		
		System.out.println(list.stream().filter(st->st.age >= 18).count());
		System.out.println("Stream using ifPreset__________");
		list.stream().filter(st->st.age==22).findAny().ifPresent(System.out::println);
		
		//another way of doing this
		/*
		Optional opt = list.stream().filter(st->st.age==22).findAny();
		if(opt.isPresent())
			System.out.println("showing stream using optional -----"+ opt.get());
		
		// another way using orELse
          		System.out.println(opt.orElse("not present"));
        */
		System.out.println("for printing --->>>>"+list.stream().filter(n->n.getAge()==25).findAny().orElseGet(()->s4));
          		
	return  list.stream().filter(stud->stud.getName().equals(name)).findAny().orElseThrow(()->(new NullPointerException()));
		
	}
	
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Student s1 = new Student(11,null,20,5000,"10");
		Student s2 = new Student(12,"xyz",20,9000,"11");
		Student s3 = new Student(14,"ijk",22,7000,"12");
		
		Optional<String> option = Optional.ofNullable(s2.getName());
		
    	if(option.isPresent())
			option.stream().forEach(e->
			
			     {
			    	 System.out.println(e);
				
			});
			
		
		//orElse() example
		/*
		Optional<String> option1 = Optional.ofNullable(s1.getName());
		System.out.println(option1.orElse("name is empty"));
		*/
    	
    	
		// orElsethrow()
		/*
		Optional<String> option1 = Optional.ofNullable(s1.getName());
		option1.orElseThrow(()->(new IllegalArgumentException()));
		*/
    	
    	// orElseGet()
    	/*
    	Optional<String> option1 = Optional.ofNullable(s1.getName());
    	System.out.println(option1.orElseGet(()->("enter valid name")));
         */
    	Optional<String> option3 = Optional.ofNullable(s3.getName());
    	System.out.println(option3.map(String::toUpperCase).orElseGet(()->("enter valid name")));
     
    	// calling this static method 
    	System.out.println(getByname("abc"));
    	// getting null pointer if name not present
    	//System.out.println(getByname("ijk"));
    	
    	List<String> lis = new ArrayList<>();
    	lis.add("mango");
    	lis.add("babana");
    	lis.add("apple");
    	
    	System.out.println("------------00000000000000---------------==========>"+lis.toString());
    	
	    lis.add(1,"grapes");
	    
	    System.out.println("------------00000000000000------------------->"+lis.toString());
	    
	  
	    
	}

}
