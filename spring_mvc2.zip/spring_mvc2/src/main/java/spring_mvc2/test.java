package spring_mvc2;

public class test {

}
