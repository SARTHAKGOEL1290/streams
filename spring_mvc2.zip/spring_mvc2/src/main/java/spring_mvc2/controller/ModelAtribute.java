package spring_mvc2.controller;

public class ModelAtribute {
	
	public String handle()
	{
		return null;
		
	}

}
