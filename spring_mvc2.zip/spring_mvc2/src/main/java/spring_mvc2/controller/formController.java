package spring_mvc2.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import spring_mvc2.controller.entity.User;

@Controller
//@RequestMapping("/start")
public class formController {
	
	@ModelAttribute
	public void CommonMessages(Model m)
	{
		m.addAttribute("header","please input required fields");
	}

	@RequestMapping("/forms")
	public String form_input()
	{
		System.out.println("enter the values in form");
		 return "forms";
	}
/*	@RequestMapping(path="/processforms",method=RequestMethod.POST)
	public String abc(HttpServletRequest request)
	{
		request.getAttribute("email");
		System.out.println("welcome");
		return "processforms";
	}
	*/
	@RequestMapping(path="/processforms",method = RequestMethod.POST)
	public String HandleForm(@ModelAttribute User user, Model model)
	{
		System.out.println("user data has been entered by ModelAttirbute Annotation");
		
		return "success";
	}
/*	@RequestMapping(path="/processforms",method = RequestMethod.POST)
public String form_mapping(@RequestParam("email") String userEmail,
			                   @RequestParam("username") String userName,
			                   Model model)
			                  
	
	{
		
		System.out.println("email is "+ userEmail);
		System.out.println("username is" + userName);
		//System.out.println("Password is "+ userPassword);
		
		User user = new User();  // for saving user Entity data
		
		user.setEmail(userEmail);
		user.setUsername(userName);
	
		
		
		/*	 when we are adding the attribute without user class
	    model.addAttribute("email",userEmail);
	    model.addAttribute("username", userName);
		model.addAttribute("Password",userPassword);
		
	*/	
	//model.addAttribute("user",user);
		
		//return "success";
	
	//}
	
	
}
