package spring_mvc2.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping("/initial")
public class HomePageController {
	
	@RequestMapping("/home")
	public String home()
	{
		System.out.println("this is home url");
		return "index";
	}
	
	@RequestMapping(path = "/first" , method = RequestMethod.GET)
	public String first(Model model)  // for handelling dynamic data
	{
		model.addAttribute("name", "sarthak");
		model.addAttribute("id", 1234);
		
		List<String> friends = new ArrayList<String>();
		friends.add("abc");
		friends.add("def");
		friends.add("xyz");
		
		model.addAttribute("frnd",friends);
		return "first";
		
	}
	
	@RequestMapping(path = "/help", method= RequestMethod.GET)
	public ModelAndView help()
	{
		System.out.println("this is help controller");
		
		// creating and object for for ModelAndView
		ModelAndView modelandview = new ModelAndView();
		
		// setting the data
		modelandview.addObject("name","sarthu");
		modelandview.addObject("id",1502991);
		
		// setting the view(or jsp page)
		modelandview.setViewName("help");;
		
		return modelandview;
		
		
	}

}
