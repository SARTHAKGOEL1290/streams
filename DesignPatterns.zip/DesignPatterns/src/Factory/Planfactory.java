package Factory;

public class Planfactory {
	
	public plan getplan(String plantype)
	{
		if(plantype==null)
			return null;
		
		else if(plantype.equalsIgnoreCase("Sbi"))
		{
			
			return new Sbi();
		}
		else if(plantype.equalsIgnoreCase("Pnb"))
	    {
			return new Pnb();
	    }
		
		return null;
	}

}
