package Factory;

public class Pnb implements plan{

	@Override
	public void InterestRate() {
		// TODO Auto-generated method stub
		System.out.println("Rate of interst of Pnb is 12%");
	}
	
	

}
