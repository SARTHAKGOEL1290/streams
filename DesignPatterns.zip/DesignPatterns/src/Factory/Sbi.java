package Factory;

public class Sbi implements plan {

	@Override
	public void InterestRate() {
		// TODO Auto-generated method stub
		System.out.println("Rate of interst of Sbi is 9%");
		
	}
	
	

}
