package Factory;

public class mainFactory {

	// the creational pattern is used to that user does not dependent on how the object is created 
	// either by new keyword or by Autowired 
	// it's the task of factory class to instantiate and return the specified object
	
	public static void main(String[] args)
	{
	   Planfactory planfactory = new Planfactory();
	   
	   plan p = planfactory.getplan("sbi");
	   p.InterestRate();
	  
	   
	   
	  
	}
}
