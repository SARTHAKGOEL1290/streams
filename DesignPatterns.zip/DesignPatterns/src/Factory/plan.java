package Factory;

public interface plan {
	
	public void InterestRate();
	

}
