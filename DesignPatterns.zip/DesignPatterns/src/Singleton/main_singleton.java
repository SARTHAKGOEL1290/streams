package Singleton;

public class main_singleton {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Thread t1 = new Thread(new Runnable() {
				
				public void run()
				{
					System.out.println("instance of thread1");
					try {
						Thread.sleep(1000);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
			      Singleton_Util obj1 = Singleton_Util.getInstance();
				}
				
		});
		
		Thread t2 = new Thread(new Runnable() {
			
			public void run()
			{
				System.out.println("instance of thread2");
		      Singleton_Util obj2 = Singleton_Util.getInstance();
			}
			
	});
	
		
		t1.start();
		t2.start();
		
    // in output only the instance of thread one is created , the time thread2 trying to  access
		// the instance of Singleton_Util class due to synchronization  it will not
		// hence principle of singleton is achieved
	}

}
