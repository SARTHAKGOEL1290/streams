package Singleton;

// the reason being for using singleton class is that we want that only one instance of our class 
// is created at one time
public class Singleton_Util  {
	
	//static instance of class
	 static Singleton_Util obj;
	 
	 // private constructor
	 private Singleton_Util()
	 {
		 System.out.println("instance created");
	 }
	 
	 // factory method to return the instance of this class to outside caller class
	public static Singleton_Util getInstance()
	 {
		 if(obj == null) {
			
		synchronized(Singleton_Util.class) {
			
			if(obj == null)
			{
				 obj= new Singleton_Util();
			}
			
		  }	 
		}
		// System.out.println("hi");
		 return obj;
	 }

}
